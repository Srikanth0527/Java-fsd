import java.io.FileReader;
import java.io.IOException;

public class FinallyBlockExample {

    public static void main(String[] args) {
        try (FileReader reader = new FileReader("myfile.txt")) {
            // Read the file contents
            char[] buffer = new char[1024];
            int charsRead;
            while ((charsRead = reader.read(buffer)) != -1) {
                System.out.print(new String(buffer, 0, charsRead));
            }
        } catch (IOException e) {
            System.out.println("Error reading file: " + e.getMessage());
        } finally {
            System.out.println("File closed");
        }
    }
}
