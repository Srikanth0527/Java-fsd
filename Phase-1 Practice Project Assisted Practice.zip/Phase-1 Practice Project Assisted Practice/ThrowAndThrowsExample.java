public class ThrowAndThrowsExample {

    public static void main(String[] args) {
        try {
            // Code that might throw an exception
            validateAge(10);
        } catch (IllegalArgumentException e) {
            System.out.println("Invalid age: " + e.getMessage());
        }
    }

    static void validateAge(int age) throws IllegalArgumentException {
        if (age < 0) {
            throw new IllegalArgumentException("Age must be non-negative");
        }
    }
}

