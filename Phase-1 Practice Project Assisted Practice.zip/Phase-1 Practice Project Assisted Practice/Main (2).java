class AccessModifiersExample {
    // Default access modifier
    int defaultVariable = 10;

    // Private access modifier
    private int privateVariable = 20;

    // Protected access modifier
    protected int protectedVariable = 30;

    // Public access modifier
    public int publicVariable = 40;

    // Default access modifier method
    void defaultMethod() {
        System.out.println("Default access modifier method");
    }

    // Private access modifier method
    private void privateMethod() {
        System.out.println("Private access modifier method");
    }

    // Protected access modifier method
    protected void protectedMethod() {
        System.out.println("Protected access modifier method");
    }

    // Public access modifier method
    public void publicMethod() {
        System.out.println("Public access modifier method");
    }
}

class ChildClass extends AccessModifiersExample {
    // Accessing default variable from parent class
    int defaultVariable = parent.defaultVariable;

    // Accessing protected variable from parent class
    int protectedVariable = parent.protectedVariable;

    // Accessing public variable from parent class
    int publicVariable = parent.publicVariable;

    // Accessing default method from parent class
    void defaultMethod() {
        parent.defaultMethod();
    }

    // Accessing protected method from parent class
    void protectedMethod() {
        parent.protectedMethod();
    }

    // Accessing public method from parent class
    void publicMethod() {
        parent.publicMethod();
    }

    // Accessing private method from parent class - Not accessible
    // private void privateMethod() {
    // parent.privateMethod();
    // }
}

public class Main {
    public static void main(String[] args) {
        AccessModifiersExample
