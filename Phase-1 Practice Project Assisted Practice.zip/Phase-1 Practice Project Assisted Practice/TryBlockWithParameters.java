public class TryBlockWithParameters {

    public static void main(String[] args) {
        try {
            validateAge(10, "User input");
        } catch (IllegalArgumentException e) {
            System.out.println("Invalid age: " + e.getMessage());
        }
    }

    static void validateAge(int age, String inputSource) throws IllegalArgumentException {
        if (age < 0) {
            throw new IllegalArgumentException("Age must be non-negative (" + inputSource + ")");
        }
    }
}

