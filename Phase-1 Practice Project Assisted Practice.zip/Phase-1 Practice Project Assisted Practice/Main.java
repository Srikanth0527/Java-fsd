class Person {
    private String name;
    private int age;
    private String occupation;

    public Person(String name, int age, String occupation) {
        this.name = name;
        this.age = age;
        this.occupation = occupation;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public String getOccupation() {
        return occupation;
    }
}

public class Main {
    public static void main(String[] args) {
        Person person = new Person("John", 30, "Software Engineer");

        System.out.println(person.getName()); // John
        System.out.println(person.getAge()); // 30
        System.out.println(person.getOccupation()); // Software Engineer
    }
}
