public class MultipleCatchBlocksExample {

    public static void main(String[] args) {
        try {
            // Code that might throw an exception
            validateInput(null);
        } catch (NullPointerException e) {
            System.out.println("Input cannot be null");
        } catch (IllegalArgumentException e) {
            System.out.println("Invalid input: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("Unexpected error: " + e.getMessage());
        }
    }

    static void validateInput(String input) throws NullPointerException, IllegalArgumentException {
        if (input == null) {
            throw new NullPointerException("Input cannot be null");
        }

        if (!input.trim().isEmpty()) {
            throw new IllegalArgumentException("Input cannot be empty");
        }
    }
}
