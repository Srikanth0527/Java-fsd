public class GeometricAreaCalculator {

    public static void main(String[] args) {
        // Calculate the area of a square
        double squareArea = calculateArea(ShapeType.SQUARE, 5);
        System.out.println("Square area: " + squareArea);

        // Calculate the area of a rectangle
        double rectangleArea = calculateArea(ShapeType.RECTANGLE, 10, 6);
        System.out.println("Rectangle area: " + rectangleArea);

        // Calculate the area of a circle
        double circleArea = calculateArea(ShapeType.CIRCLE, 4);
        System.out.println("Circle area: " + circleArea);

        // Calculate the area of a triangle
        double triangleArea = calculateArea(ShapeType.TRIANGLE, 8, 3);
        System.out.println("Triangle area: " + triangleArea);
    }

    public enum ShapeType {
        SQUARE, RECTANGLE, CIRCLE, TRIANGLE
    }

    public static double calculateArea(ShapeType shapeType, double... dimensions) {
        switch (shapeType) {
            case SQUARE:
                double sideLength = dimensions[0];
                return sideLength * sideLength;
            case RECTANGLE:
                double length = dimensions[0];
                double width = dimensions[1];
                return length * width;
            case CIRCLE:
                double radius = dimensions[0];
                return Math.PI * radius * radius;
            case TRIANGLE:
                double base = dimensions[0];
                double height = dimensions[1];
                return 0.5 * base * height;
            default:
                throw new IllegalArgumentException("Invalid shape type: " + shapeType);
        }
    }
}
