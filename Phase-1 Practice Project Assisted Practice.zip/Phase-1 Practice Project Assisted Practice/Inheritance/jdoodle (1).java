class Animal {
    private String name;

    public Animal(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}

class Dog extends Animal {
    private String breed;

    public Dog(String name, String breed) {
        super(name);
        this.breed = breed;
    }

    public String getBreed() {
        return breed;
    }
}

class Labrador extends Dog {
    private String color;

    public Labrador(String name, String breed, String color) {
        super(name, breed);
        this.color = color;
    }

    public String getColor() {
        return color;
    }
}
