public class TypeCastingExample {

    public static void main(String[] args) {
        // Implicit type casting
        int intValue = 10;
        double doubleValue = intValue; // Implicit type casting from int to double

        System.out.println("Implicit type casting:");
        System.out.println("intValue: " + intValue);
        System.out.println("doubleValue: " + doubleValue);

        // Explicit type casting
        double doubleValue2 = 15.5;
        int intValue2 = (int) doubleValue2; // Explicit type casting from double to int

        System.out.println("\nExplicit type casting:");
        System.out.println("doubleValue2: " + doubleValue2);
        System.out.println("intValue2: " + intValue2);
    }
}
