import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.TreeSet;

public class CollectionVerifier {

    public static void main(String[] args) {
        verifyList(new ArrayList<>());
        verifySet(new HashSet<>());
        verifyQueue(new LinkedList<>());
        verifySortedSet(new TreeSet<>());
    }

    private static void verifyList(List<Object> list) {
        // Verify basic list operations
        list.add("apple");
        list.add("banana");
        list.add("orange");

        System.out.println("List contents: " + list);

        System.out.println("Contains apple: " + list.contains("apple"));
        System.out.println("Index of banana: " + list.indexOf("banana"));
        System.out.println("Remove orange: " + list.remove("orange"));

        System.out.println("Updated list contents: " + list);
    }

    private static void verifySet(Set<Object> set) {
        // Verify basic set operations
        set.add("apple");
        set.add("banana");
        set.add("orange");

        System.out.println("Set contents: " + set);

        System.out.println("Contains apple: " + set.contains("apple"));
        System.out.println("Remove orange: " + set.remove("orange"));

        System.out.println("Updated set contents: " + set);
    }

    private static void verifyQueue(Queue<Object> queue) {
        // Verify basic queue operations
        queue.offer("apple");
        queue.offer("banana");
        queue.offer("orange");

        System.out.println("Queue contents: " + queue);

        System.out.println("Poll first element: " + queue.poll());
        System.out.println("Peek at next element: " + queue.peek());

        System.out.println("Updated queue contents: " + queue);
    }

    private static void verifySortedSet(SortedSet<Object> sortedSet) {
        // Verify basic sorted set operations
        sortedSet.add("apple");
        sortedSet.add("banana");
        sortedSet.add("orange");

        System.out.println("Sorted set contents: " + sortedSet);

        System.out.println("First element: " + sortedSet.first());
        System.out.println("Last element: " + sortedSet.last());

        System.out.println("Updated sorted set contents: " + sortedSet);
    }
}
